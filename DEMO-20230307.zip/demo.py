import numpy as np

def print_hello_world():
    print("Hello World!")

def return_hello_world():
    return "Hello World!"

def create_1d_np_array(size: int = 1) -> np.array:
    return np.zeros(size)